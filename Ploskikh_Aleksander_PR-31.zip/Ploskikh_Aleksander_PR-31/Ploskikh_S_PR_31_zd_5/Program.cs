﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Ploskikh_S_PR_31_zd_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] lines = File.ReadAllLines("input.txt");
            int n = Convert.ToInt32(lines[0]);
            string[] par = lines[1].Split(' ');
            int v = Convert.ToInt32(par[0]);
            int t = Convert.ToInt32(par[1]);
            int k = (v * t) % n;
            File.WriteAllText("output.txt", k.ToString());
        }
    }
}
