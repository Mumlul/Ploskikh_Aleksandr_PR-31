﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ploskikh_S_PR_31_zd_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int k = -1;
            int n;
            int r;   
            string[] m = File.ReadAllText("input.txt").Split(' ');
            k = Convert.ToInt32(m[0]);
            n = Convert.ToInt32(m[1]);
            if((k < 0 || k > 100) && !(n < 1 && n > Math.Pow(10, 4)))
            {
                r = n / k;
                File.WriteAllText("output.txt", r.ToString());
            }
        }
    }
}
