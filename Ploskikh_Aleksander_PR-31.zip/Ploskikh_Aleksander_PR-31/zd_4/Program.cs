﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ploskikh_S_PR_31_zd_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] inputlines = File.ReadAllLines("input.txt");
            string[] first = inputlines[0].Split(' ');
            int messagel = Convert.ToInt32(first[0]);
            int newsl= Convert.ToInt32(first[1]);
            string mes = inputlines[1];
            string news = inputlines[2];

            string[] mesw = mes.Split(' ');
            string[] neww = news.Split(' ');

            Dictionary<string, int> wcount = new Dictionary<string, int>();
            foreach(var word in neww)
            {
                if (wcount.ContainsKey(word)) wcount[word]++;
                else wcount[word] = 1;
            }

            foreach(var word in mesw)
            {
                if (!wcount.ContainsKey(word) || wcount[word] == 0) 
                {
                    File.WriteAllText("output.txt", word);
                    return;
                }
                wcount[word]--;
            }
            string result = "GOOD NOTE";
            File.WriteAllText("output.txt", result);
        }
    }
}
